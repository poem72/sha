///////////////////////////
///
// Importing the config.js file
const token = require('./config.js').token;

// Output the token to ensure it's retrieved correctly
console.log("Token from config.js:", token);

module.exports = {
    showTime: false,
    timeZone: "Asia/Kolkata", //Your Timezone, eg Asia/Kolkata
    Name: "Eric Music",
    State: "Just shut up",
    Details: "ُُEric bot",
    LargeImage: "https://cdn.discordapp.com/attachments/1279166335909232762/1284528314429739081/1.jpg?ex=66e6f5b7&is=66e5a437&hm=6e47d33a7135e9bf43be52e6abca4949bc757cd1f3b00cb63fa04e25024b88fc&",
    SmallImage: "https://cdn.discordapp.com/attachments/1279166335909232762/1284528314429739081/1.jpg?ex=66e6f5b7&is=66e5a437&hm=6e47d33a7135e9bf43be52e6abca4949bc757cd1f3b00cb63fa04e25024b88fc&",
    SmallText: "...", // hover text for small image
  };
  