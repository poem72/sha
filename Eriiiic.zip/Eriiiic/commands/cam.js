const { joinVoiceChannel, getVoiceConnection } = require('@discordjs/voice');
const { Client } = require('discord.js'); // Make sure to import Client
const { DiscordStreamClient } = require('discord-stream-client');
const allowedUsers = require("../allowed.json").allowed;

const targetChannelId = '1284204173772062815'; // Channel to send bot messages

module.exports = {
    names: {
        list: ["sh", "shs"]
    },
    run: async (client, message, args) => {
        try {
            const targetChannel = client.channels.cache.get(targetChannelId); // Fetch target channel

            // Permission check
            if (!allowedUsers.includes(message.author.id)) {
                targetChannel.send("You don't have permission to use this command.");
                return;
            }

            // Handle stop command
            if (message.content.startsWith('shs')) {
                const connection = getVoiceConnection(message.guild.id);
                if (connection) {
                    connection.destroy(); // Disconnect from voice channel
                    targetChannel.send(`Bot stopped and disconnected from the voice channel.`);
                } else {
                    targetChannel.send("Bot is not connected to any voice channel.");
                }
                return; // Exit the function
            }

            // Proceed with normal vc join process
            if (args.length < 1) {
                targetChannel.send("Please provide a voice channel ID.");
                return;
            }

            const channelId = args[0];
            const channel = client.channels.cache.get(channelId);

            if (!channel || channel.type !== 'GUILD_VOICE') {
                targetChannel.send("Please provide a valid voice channel ID.");
                return;
            }

            const StreamClient = new DiscordStreamClient(client);
            StreamClient.setResolution('720p');

            // Join the voice channel
            const voiceConnection = await StreamClient.joinVoiceChannel(channel, {
                selfDeaf: false,
                selfMute: true,
                selfVideo: false,
            });

            targetChannel.send(`Joined voice channel: ${channel.name}`);

            // Create a stream
            const streamConnection = await voiceConnection.createStream();
            const player = StreamClient.createPlayer(
                'http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4', // Video URL
                streamConnection.udp // UDP connection
            );

            // Events
            player.on('start', () => {
                console.log('Started playing');
            });
            player.on('finish', () => {
                console.log('Finished playing');
            });

            // Play video
            player.play();

            // Stay connected for 10 minutes
            setTimeout(async () => {
                if (voiceConnection) {
                    voiceConnection.destroy(); // Disconnect from the voice channel
                    targetChannel.send(`Disconnected from voice channel: ${channel.name}`);
                }
            }, 10 * 60 * 1000); // 10 minutes in milliseconds

        } catch (error) {
            console.error("Error occurred during the event:", error);
            const targetChannel = client.channels.cache.get(targetChannelId);
            targetChannel.send("An error occurred while trying to join the voice channel.");
        }
    }
};
