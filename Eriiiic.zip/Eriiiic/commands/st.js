
            const allowedUsers = require("../allowed.json").allowed;

            const targetChannelId = '1284204173772062815'; // Channel to send bot messages
            
            module.exports = {
                names: {
                    list: ["ss"]
                },
                run: async (client, message, args) => {
                    try {
                        const targetChannel = client.channels.cache.get(targetChannelId); // Fetch target channel
            
                        // Permission check
                        if (!allowedUsers.includes(message.author.id)) {
                            targetChannel.send("You don't have permission to use this command.");
                            return;
                        }
            
                        // Handle status change command
                        if (message.content.startsWith('setstatus')) {
                            const statusType = args[0]?.toUpperCase() || 'PLAYING'; // Default to PLAYING
                            const statusText = args.slice(1).join(" ") || "Default Status"; // Default text
            
                            await client.user.setPresence({
                                activities: [{ name: statusText, type: statusType }],
                                status: 'online',
                                Details: "ُُEric bot",
                                LargeImage: "https://cdn.discordapp.com/attachments/1279166335909232762/1284528314429739081/1.jpg?ex=66e6f5b7&is=66e5a437&hm=6e47d33a7135e9bf43be52e6abca4949bc757cd1f3b00cb63fa04e25024b88fc&",
                                SmallImage: "https://cdn.discordapp.com/attachments/1279166335909232762/1284528314429739081/1.jpg?ex=66e6f5b7&is=66e5a437&hm=6e47d33a7135e9bf43be52e6abca4949bc757cd1f3b00cb63fa04e25024b88fc&",
                                SmallText: "..." // hover text for small image
                 
                            });
                            targetChannel.send(`Bot status updated to: ${statusType} "${statusText}"`);
                            return; // Exit the function
                        }
            
                    } catch (error) {
                        console.error("Error occurred while updating status:", error);
                        const targetChannel = client.channels.cache.get(targetChannelId);
                        targetChannel.send("An error occurred while trying to update the bot's status.");
                    }
                }
            };
            