const { Client, GatewayIntentBits, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { Client: SSHClient } = require('ssh2');
const fs = require('fs');
const readline = require('readline');
const axios = require('axios');

const DISCORD_TOKEN = '';
const SSH_CONFIG = {
    host: '216.155.135.47',
    port: 22,
    username: 'master_jnrmygjgqx',
    password: 'Ssaa1122'
};

const ERROR_CHANNEL_ID = '1284504473737232498';  // Error reporting channel ID
let runDelay = 140000;  // Default time delay between bot launches in milliseconds
const activeTokens = new Set();  // Tokens that have been used
let usedTokens = new Set();  // To store used tokens

const bot = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent
    ]
});

bot.once('ready', () => {
    console.log(`Logged in as ${bot.user.tag}`);
});

// Error handling - send errors to a specific channel
bot.on('error', (error) => {
    const errorChannel = bot.channels.cache.get(ERROR_CHANNEL_ID);
    if (errorChannel) {
        errorChannel.send(`An error occurred: ${error.message}`);
    } else {
        console.error('Error channel not found.');
    }
});
bot.on('messageCreate', async message => {
    // Other commands...

    // Help command
    if (message.content === '!help') {
        const helpEmbed = new EmbedBuilder()
            .setTitle('Bot Help Commands By Eric')
            .setColor('#00FF00')  // Set embed color to green
            .setDescription('Here are all the available commands:')
            .addFields(
                { name: '!setup', value: 'لفتح فائمة الاوامر' },
                { name: '!run <number>', value: 'تشغيل عدد معين من التوكنات' },
                { name: '!runonebyone', value: 'تشغيل كل التوكنات' },
                { name: '!setdelay <milliseconds>', value: 'تغير الوقت المدد بين تشغيل كل توكن (لتفادي الاخطاء لازم يكون الوقت اكثر من 3 دقايق' },
                { name: '!tokensleft', value: 'لعرض التوكنات المتبقية.' },
                { name: '!tokensused', value: 'لعرض التوكنات المشغلة' },
                { name: '!help', value: 'قائمة الاوامر' }, 
            )
            .setFooter({ text: 'اوامر البوت ' });

        // Send the help embed
        await message.reply({ embeds: [helpEmbed] });
    }

    // Other commands...
});
bot.on('messageCreate', async message => {
    // Other commands...

    // Help command
    if (message.content === '!helpt') {
        const helpEmbed = new EmbedBuilder()
            .setTitle('Bot Help Commands By Eric')
            .setColor('#00FF00')  // Set embed color to green
            .setDescription('Here are all the available commands:')
            .addFields(
                { name: 'vc', value: 'join vc' },
                { name: 'mu', value: 'join vc mute' },
                { name: 'def', value: 'join vc def' },
                { name: 'react', value: 'react to message' },
                { name: 'reactstart', value: 'react to channel' },
                { name: 'sh', value: 'join vc and stream' },
            )
            .setFooter({ text: 'اوامر البوت ' });

        // Send the help embed
        await message.reply({ embeds: [helpEmbed] });
    }

    // Other commands...
});
let configFilePath = '/home/master/sah/Eriiiic/config.js';  // Default path

bot.on('messageCreate', async message => {
    // Other commands...

    // Command to change the config file path
    if (message.content.startsWith('!setpath')) {
        const args = message.content.split(' ');
        if (args.length < 2) {
            message.reply('Please provide a valid path.');
            return;
        }

        configFilePath = args[1];
        message.reply(`Config file path has been changed to: ${configFilePath}`);
    }
});
// Define the embed buttons panel command
bot.on('messageCreate', async message => {
    if (message.content === '!setup') {
        // Create an interactive embed panel with buttons
        const embed = new EmbedBuilder()
            .setTitle('Bot Control Panel')
            .setDescription('Choose an action:')
            .setColor('#00FF00');  // Set the color as hex (green)

        // Create buttons for the panel
        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('runall')
                    .setLabel('تشغيل كل التوكنات')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('check_tokens')
                    .setLabel('عدد التوكنات المتوفر')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('screen_status')
                    .setLabel('Show Screen Status')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('shutdown_screens')
                    .setLabel('اعادة تشغيل كل التوكنات')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('shutdown_by_number')
                    .setLabel('Shut Down Screen by Number')
                    .setStyle(ButtonStyle.Secondary)
            );

        // Send the embed with buttons
        await message.reply({ embeds: [embed], components: [row] });
    }

    // Run bots by the number of tokens chosen
    else if (message.content.startsWith('!run')) {
        const args = message.content.split(' ');
        const numBots = parseInt(args[1], 10);

        if (isNaN(numBots) || numBots <= 0) {
            message.reply('Please provide a valid number of bots to run.');
            return;
        }

        const tokens = await readTokensFromFile('tokens.txt');
        const availableTokens = tokens.filter(token => !activeTokens.has(token));

        if (availableTokens.length < numBots) {
            message.reply(`Not enough available tokens to run ${numBots} bots.`);
            return;
        }

        for (let i = 0; i < numBots; i++) {
            const token = availableTokens[i];
            const configFilePath = '/home/master/sah/Eriiiic/config.js';

            await new Promise((resolve, reject) => {
                updateConfigFile(configFilePath, token, (err) => {
                    if (err) {
                        message.reply(`Failed to update config file: ${err.message}`);
                        reject(err);
                        return;
                    }

                    activeTokens.add(token);
                    usedTokens.add(token);  // Track the used tokens
                    runBotOnSSH(message, token, resolve);
                });
            });
        }

        message.reply(`${numBots} bots started successfully!`);
    }

    // Run bots one by one with default delay
    else if (message.content.startsWith('!runonebyone')) {
        const tokens = await readTokensFromFile('tokens.txt');
        const availableTokens = tokens.filter(token => !activeTokens.has(token));

        if (availableTokens.length === 0) {
            message.reply('No available tokens to run.');
            return;
        }

        for (const token of availableTokens) {
            const configFilePath = '/home/master/sah/Eriiiic/config.js';

            await new Promise((resolve, reject) => {
                setTimeout(() => {
                    updateConfigFile(configFilePath, token, (err) => {
                        if (err) {
                            message.reply(`Failed to update config file: ${err.message}`);
                            reject(err);
                            return;
                        }

                        activeTokens.add(token);
                        usedTokens.add(token);  // Track the used tokens
                        runBotOnSSH(message, token, resolve);
                    });
                }, runDelay);
            });
        }

        message.reply('Bots started one by one with delay!');
    }

    // Set custom delay for running bots in runall
    else if (message.content.startsWith('!setdelay')) {
        const args = message.content.split(' ');
        const newDelay = parseInt(args[1], 10);

        if (isNaN(newDelay) || newDelay <= 0) {
            message.reply('Please provide a valid time delay in milliseconds.');
            return;
        }

        runDelay = newDelay;
        message.reply(`Time delay between bot launches set to ${runDelay} milliseconds.`);
    }

    // Show remaining tokens
    else if (message.content === '!tokensleft') {
        const tokens = await readTokensFromFile('tokens.txt');
        const availableTokens = tokens.filter(token => !activeTokens.has(token));
        message.reply(`There are ${availableTokens.length} tokens left to run.`);
    }

    // Show used tokens
    else if (message.content === '!tokensused') {
        message.reply(`The bot has used ${usedTokens.size} tokens.`);
    }
});

// Handle button interactions
bot.on('interactionCreate', async interaction => {
    if (!interaction.isButton()) return;

    const tokens = await readTokensFromFile('tokens.txt');
    const availableTokens = tokens.filter(token => !activeTokens.has(token));

    switch (interaction.customId) {
        case 'runall':
            if (availableTokens.length === 0) {
                await interaction.reply('No available tokens to run.');
                return;
            }

            for (const token of availableTokens) {
                const configFilePath = '/home/master/sah/Eriiiic/config.js';

                await new Promise((resolve, reject) => {
                    setTimeout(() => {
                        updateConfigFile(configFilePath, token, (err) => {
                            if (err) {
                                interaction.reply(`Failed to update config file: ${err.message}`);
                                reject(err);
                                return;
                            }

                            activeTokens.add(token);
                            usedTokens.add(token);  // Track the used tokens
                            runBotOnSSH(interaction, token, resolve);
                        });
                    }, runDelay);
                });
            }

            await interaction.reply('All available bots started successfully!');
            break;

        case 'check_tokens':
            await interaction.reply(`There are ${availableTokens.length} available tokens.`);
            break;

        case 'screen_status':
            await interaction.reply('There are X screens currently running.');  // Implement screen status logic
            break;

        case 'shutdown_screens':
            await interaction.reply('All screens shut down successfully.');  // Implement shutdown logic
            break;

        case 'shutdown_by_number':
            await interaction.reply('Please specify the screen number to shut down.');  // Implement shutdown by number
            break;

        default:
            await interaction.reply('Invalid button.');
            break;
    }
});

// Other helper functions remain the same
async function readTokensFromFile(filePath) {
    const fileStream = fs.createReadStream(filePath);
    const rl = readline.createInterface({
        input: fileStream,
        crlfDelay: Infinity
    });

    const tokens = [];
    for await (const line of rl) {
        tokens.push(line.trim());
    }

    return tokens;
}

function updateConfigFile(configFilePath, newToken, callback) {
    fs.readFile(configFilePath, 'utf8', (err, data) => {
        if (err) {
            callback(err);
            return;
        }

        const updatedConfig = data.replace(/token:\s*".*"/, `token: "${newToken}"`);

        fs.writeFile(configFilePath, updatedConfig, 'utf8', callback);
    });
}

function runBotOnSSH(interaction, token, callback) {
    const conn = new SSHClient();
    conn.on('ready', () => {
        console.log('SSH Client :: ready');
        conn.exec('cd /home/master/sah/Eriiiic && screen -dmS bot_session_name node index.js', (err, stream) => {
            if (err) {
                interaction.reply(`Failed to execute command: ${err.message}`);
                activeTokens.delete(token);  // Ensure token is removed on failure
                if (callback) callback(err);
                return;
            }
            stream.on('close', () => {
                interaction.reply(`Bot started successfully with token: ${token}`);
                if (callback) callback();
            });
        });
    }).connect(SSH_CONFIG);
}

bot.login(DISCORD_TOKEN);
