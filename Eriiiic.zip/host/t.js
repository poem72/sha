const DISCORD_TOKEN = 'MTI4NDQ5OTg0ODExNjE3NDg0OA.GVurB2.x5uLpggJZx-3e3epnR1dSR-Ei2Qks0bi0Ovnlo';
const SSH_CONFIG = {
    host: '143.198.14.182',
    port: 22,
    username: 'master_mjfrfgyrsq',
    password: 'Ssaa1122'
};